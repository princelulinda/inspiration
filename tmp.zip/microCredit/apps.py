from django.apps import AppConfig


class MicrocreditConfig(AppConfig):
    name = 'microCredit'
