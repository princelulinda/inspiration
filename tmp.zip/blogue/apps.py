from django.apps import AppConfig


class BlogueConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'blogue'
