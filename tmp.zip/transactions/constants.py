DEPOSIT = 'deposit'
WITHDRAWAL = 'withdrawal'
INTEREST = 'interest'

TRANSACTION_TYPE_CHOICES = (
    (DEPOSIT, 'Deposit'),
    (WITHDRAWAL, 'Withdrawal'),
    (INTEREST, 'Interest'),
)
